# Welcrevit-joution wil-parser
Python application tn  arse journ

l  Biles into a hs will uh Ln reA --> C(Round Rect)
B --> D{Rhombus}
C --> D
```
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTExOTE5NDgxNzldfQ==
-->